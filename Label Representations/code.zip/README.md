https://github.com/BoyuanChen/label_representations contains the code from the original paper ->
git clone https://github.com/BoyuanChen/label_representations.git

comp551_mini_project_4 is a chronologically ordered step-by-step reproduction notebook of the results in writeup.pdf

Contributions: Max Zhang (me) conducted experiments and wrote the report.